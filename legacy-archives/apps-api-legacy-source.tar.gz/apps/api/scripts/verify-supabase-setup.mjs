import { config } from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { createClient } from "@supabase/supabase-js";

// Get the directory of the current script
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables from .env file in project root
config({ path: path.resolve(__dirname, "../../../.env") });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
const placeholderUrls = ["https://example.supabase.co", "service-role-placeholder"];

console.log("🔍 Verifying Supabase setup...\n");

if (!supabaseUrl || !supabaseKey) {
  console.error("❌ Missing SUPABASE_URL or SUPABASE_SERVICE_KEY");
  console.log("   Make sure .env file exists with proper values");
  process.exit(1);
}

if (placeholderUrls.includes(supabaseUrl) || placeholderUrls.includes(supabaseKey)) {
  console.error("❌ Supabase credentials are still placeholder values");
  console.log("   Please follow SUPABASE_SETUP_GUIDE.md to configure real credentials");
  process.exit(1);
}

console.log("✅ Environment variables configured");

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false },
});

try {
  // Test connection and table access
  const { count, error: countError } = await supabase
    .from("itineraries")
    .select("*", { count: "exact", head: true });

  if (countError) {
    console.error("❌ Cannot access itineraries table:", countError.message);
    console.log("   Make sure to run the migration: supabase db push");
    process.exit(1);
  }

  console.log("✅ Database connection successful");
  console.log(`✅ itineraries table exists (${count} rows)`);

  // Test seed capability
  console.log("\n🔄 Testing seed capability...");
  const testData = [{
    cities: ["Test City"],
    countries: ["VN"],
    start_date: "2026-12-01",
    end_date: "2026-12-02",
    num_days: 2,
    budget: 100,
    currency: "USD",
    trip_style: "test",
    status: "complete",
    is_public: false,
    result: { title: "Setup Test Itinerary", test: true }
  }];

  const { error: insertError } = await supabase
    .from("itineraries")
    .insert(testData);

  if (insertError) {
    console.error("❌ Cannot insert into itineraries:", insertError.message);
    console.log("   Check RLS policies or service key permissions");
    process.exit(1);
  }

  // Clean up test data
  await supabase
    .from("itineraries")
    .delete()
    .eq("name", "Setup Test Itinerary");

  console.log("✅ Seed capability verified");

  console.log("\n🎉 Supabase setup is ready!");
  console.log("   Run 'pnpm exec playwright test' to see auto-seeding in action");

} catch (error) {
  console.error("❌ Setup verification failed:", error.message);
  process.exit(1);
}
