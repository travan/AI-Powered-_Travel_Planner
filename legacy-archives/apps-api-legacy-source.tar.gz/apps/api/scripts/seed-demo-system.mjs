import crypto from "node:crypto";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import pg from "pg";
import { MongoClient } from "mongodb";

const scriptDir = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: resolve(scriptDir, "../../../.env") });

const { Client } = pg;
const postgresUrls = unique([
  process.env.POSTGRES_URL,
  process.env.DATABASE_URL,
  ...splitCsv(process.env.POSTGRES_URLS),
  ...splitCsv(process.env.DATABASE_URLS),
]);
const mongoUris = unique([
  process.env.MONGODB_URI,
  ...splitCsv(process.env.MONGODB_URIS),
]);

if (postgresUrls.length === 0) {
  console.error("POSTGRES_URL, DATABASE_URL, POSTGRES_URLS, or DATABASE_URLS is required.");
  process.exit(1);
}
if (mongoUris.length === 0) {
  console.error("MONGODB_URI or MONGODB_URIS is required.");
  process.exit(1);
}

const demoPasswordHash = hashPassword("demo123456");
const users = [
  ["host@horizon.local", "Mai Anh", "ha-noi", { style: "culture", budget: "mid_range" }],
  ["linh@horizon.local", "Linh Pham", "da-nang", { style: "food", budget: "budget" }],
  ["khoa@horizon.local", "Khoa Nguyen", "ho-chi-minh-city", { style: "adventure", budget: "mid_range" }],
  ["minh@horizon.local", "Minh Tran", "da-lat", { style: "relax", budget: "luxury" }],
  ["an@horizon.local", "An Le", "hoi-an", { style: "family", budget: "mid_range" }],
  ["viewer@horizon.local", "Viewer Demo", "nha-trang", { style: "mixed", budget: "budget" }],
];

const places = [
  ["banh-mi-phuong", "hoi-an", "Banh Mi Phuong", "Bánh Mì Phượng", "restaurant", "street-food", "2b Phan Chu Trinh, Hội An", 15.8797, 108.3278, ["banh-mi", "local-food"], 1, 4.5, 0.95],
  ["mot-hoi-an", "hoi-an", "Mot Hoi An", "Mót Hội An", "cafe", "herbal-drink", "150 Trần Phú, Hội An", 15.879, 108.329, ["drink", "old-town"], 1, 4.4, 0.9],
  ["basket-boat-cam-thanh", "hoi-an", "Cam Thanh Basket Boat", "Thuyền thúng Cẩm Thanh", "activity", "eco-tour", "Cẩm Thanh, Hội An", 15.887, 108.363, ["river", "family"], 2, 4.6, 0.88],
  ["my-khe-beach", "da-nang", "My Khe Beach", "Biển Mỹ Khê", "attraction", "beach", "Võ Nguyên Giáp, Đà Nẵng", 16.061, 108.247, ["beach", "sunrise"], 1, 4.6, 0.94],
  ["madame-lan", "da-nang", "Madame Lan", "Madame Lân", "restaurant", "vietnamese", "04 Bạch Đằng, Đà Nẵng", 16.072, 108.223, ["family", "local-food"], 3, 4.3, 0.87],
  ["cong-caphe-danang", "da-nang", "Cong Caphe Da Nang", "Cộng Cà Phê Đà Nẵng", "cafe", "coffee", "98-96 Bạch Đằng, Đà Nẵng", 16.068, 108.224, ["coffee", "river-view"], 2, 4.2, 0.82],
  ["temple-literature", "ha-noi", "Temple of Literature", "Văn Miếu Quốc Tử Giám", "attraction", "heritage", "58 Quốc Tử Giám, Hà Nội", 21.028, 105.835, ["heritage", "culture"], 2, 4.6, 0.9],
  ["giang-cafe", "ha-noi", "Giang Cafe", "Cà Phê Giảng", "cafe", "egg-coffee", "39 Nguyễn Hữu Huân, Hà Nội", 21.033, 105.853, ["egg-coffee", "old-quarter"], 1, 4.5, 0.92],
  ["bun-cha-huong-lien", "ha-noi", "Bun Cha Huong Lien", "Bún Chả Hương Liên", "restaurant", "local-food", "24 Lê Văn Hưu, Hà Nội", 21.018, 105.853, ["bun-cha", "local-food"], 2, 4.2, 0.83],
  ["trang-an", "ninh-binh", "Trang An Scenic Landscape", "Tràng An", "attraction", "boat-tour", "Tràng An, Ninh Bình", 20.253, 105.918, ["boat", "heritage"], 2, 4.7, 0.95],
  ["mua-cave", "ninh-binh", "Mua Cave", "Hang Múa", "attraction", "viewpoint", "Ninh Xuân, Ninh Bình", 20.227, 105.936, ["hike", "viewpoint"], 2, 4.5, 0.86],
  ["dalat-memory-inn", "da-lat", "Dalat Memory Inn", "Dalat Memory Inn", "homestay", "homestay", "Đường Triệu Việt Vương, Đà Lạt", 11.932, 108.433, ["couple", "garden"], 3, 4.4, 0.78],
  ["la-viet-coffee", "da-lat", "La Viet Coffee", "La Việt Coffee", "cafe", "specialty-coffee", "200 Nguyễn Công Trứ, Đà Lạt", 11.961, 108.444, ["coffee", "workshop"], 2, 4.5, 0.84],
  ["phu-quoc-night-market", "phu-quoc", "Phu Quoc Night Market", "Chợ đêm Phú Quốc", "attraction", "night-market", "Dương Đông, Phú Quốc", 10.216, 103.959, ["seafood", "nightlife"], 2, 4.2, 0.8],
  ["starfish-beach", "phu-quoc", "Starfish Beach", "Bãi Sao Sao Biển", "attraction", "beach", "Rạch Vẹm, Phú Quốc", 10.331, 103.905, ["beach", "family"], 1, 4.1, 0.73],
  ["bun-quay-kien-xay", "phu-quoc", "Bun Quay Kien Xay", "Bún Quậy Kiến Xây", "restaurant", "local-food", "28 Bạch Đằng, Phú Quốc", 10.217, 103.959, ["seafood", "local-food"], 2, 4.2, 0.79],
  ["phu-quoc-family-resort", "phu-quoc", "Phu Quoc Family Resort", "Phu Quoc Family Resort", "hotel", "resort", "Long Beach, Phú Quốc", 10.188, 103.966, ["pool", "beach"], 4, 4.3, 0.76],
  ["sailing-club-nhatrang", "nha-trang", "Sailing Club Nha Trang", "Sailing Club Nha Trang", "restaurant", "beach-club", "72-74 Trần Phú, Nha Trang", 12.233, 109.196, ["beach", "nightlife"], 4, 4.2, 0.76],
  ["po-nagar", "nha-trang", "Po Nagar Cham Towers", "Tháp Bà Ponagar", "attraction", "heritage", "2 Tháng 4, Nha Trang", 12.265, 109.196, ["heritage", "culture"], 2, 4.5, 0.84],
  ["hon-mun-snorkeling", "nha-trang", "Hon Mun Snorkeling", "Lặn ngắm san hô Hòn Mun", "activity", "snorkeling", "Hòn Mun, Nha Trang", 12.169, 109.301, ["island", "snorkeling"], 3, 4.4, 0.81],
  ["nha-trang-seaview-hotel", "nha-trang", "Nha Trang Seaview Hotel", "Nha Trang Seaview Hotel", "hotel", "beach-hotel", "Trần Phú, Nha Trang", 12.236, 109.196, ["sea-view", "family"], 3, 4.1, 0.72],
  ["imperial-city-hue", "hue", "Imperial City Hue", "Đại Nội Huế", "attraction", "heritage", "Phú Hậu, Huế", 16.469, 107.578, ["heritage", "history"], 2, 4.6, 0.9],
  ["hue-garden-house", "hue", "Hue Garden House", "Nhà vườn Huế", "homestay", "garden-house", "Kim Long, Huế", 16.466, 107.56, ["heritage", "quiet"], 2, 4.4, 0.74],
  ["cai-rang-market", "can-tho", "Cai Rang Floating Market", "Chợ nổi Cái Răng", "attraction", "floating-market", "Cái Răng, Cần Thơ", 10.009, 105.79, ["mekong", "morning"], 2, 4.4, 0.86],
  ["can-tho-riverside-homestay", "can-tho", "Can Tho Riverside Homestay", "Can Tho Riverside Homestay", "homestay", "river", "Cái Răng, Cần Thơ", 10.015, 105.778, ["river", "local-life"], 2, 4.3, 0.77],
  ["fansipan-cable-car", "sa-pa", "Fansipan Cable Car", "Cáp treo Fansipan", "activity", "mountain", "Fansipan, Sa Pa", 22.303, 103.775, ["mountain", "viewpoint"], 4, 4.5, 0.86],
  ["hotel-danang-river", "da-nang", "Horizon River Hotel", "Horizon River Hotel", "hotel", "river-hotel", "Bạch Đằng, Đà Nẵng", 16.07, 108.224, ["river-view", "family"], 4, 4.3, 0.7],
  ["hoi-an-lantern-homestay", "hoi-an", "Hoi An Lantern Homestay", "Hoi An Lantern Homestay", "homestay", "old-town", "Nguyễn Thái Học, Hội An", 15.877, 108.326, ["old-town", "budget"], 2, 4.4, 0.73],
  ["hanoi-family-hotel", "ha-noi", "Hanoi Family Boutique Hotel", "Hanoi Family Boutique Hotel", "hotel", "old-quarter", "Hàng Bạc, Hà Nội", 21.034, 105.853, ["old-quarter", "family"], 3, 4.2, 0.72],
];

const transportProviders = [
  ["flight", "VN", "Vietnam Airlines", "VN"],
  ["flight", "VJ", "Vietjet Air", "VN"],
  ["train", "VNR", "Vietnam Railways", "VN"],
  ["bus", "FUTA", "Futa Bus Lines", "VN"],
  ["ferry", "PQF", "Phu Quoc Express", "VN"],
  ["ferry", "HANRIVER", "Han River Ferry", "VN"],
  ["boat", "HANRIVER", "Han River Boat", "VN"],
  ["motorbike", "TIGIT", "Tigit Motorbikes", "VN"],
  ["taxi", "GRAB", "Grab", "VN"],
];
const transportHubs = [
  ["airport", "HAN", "Noi Bai International Airport", "ha-noi"],
  ["airport", "SGN", "Tan Son Nhat International Airport", "ho-chi-minh-city"],
  ["airport", "DAD", "Da Nang International Airport", "da-nang"],
  ["airport", "PQC", "Phu Quoc International Airport", "phu-quoc"],
  ["train_station", "SG", "Saigon Railway Station", "ho-chi-minh-city"],
  ["train_station", "DN", "Da Nang Railway Station", "da-nang"],
  ["train_station", "HN", "Ha Noi Railway Station", "ha-noi"],
  ["bus_station", "MDE", "Mien Dong Bus Station", "ho-chi-minh-city"],
  ["bus_station", "DL", "Da Lat Intercity Bus Station", "da-lat"],
  ["port", "RG", "Rach Gia Port", "phu-quoc"],
  ["port", "BTH", "Bai Vong Port", "phu-quoc"],
  ["pier", "BDP", "Bach Dang Pier", "da-nang"],
  ["pier", "CKP", "Cam Kim Pier", "hoi-an"],
];

let lastError;
for (const postgresUrl of postgresUrls) {
  try {
    await seed(postgresUrl, mongoUris[0]);
    process.exit(0);
  } catch (error) {
    lastError = error;
    console.warn("Demo system seed failed for one PostgreSQL URL, trying next fallback if available.");
  }
}
throw lastError;

async function seed(postgresUrl, mongoUri) {
  const client = new Client({ connectionString: postgresUrl });
  const mongo = new MongoClient(mongoUri, { serverSelectionTimeoutMS: 5000 });

  try {
    await client.connect();
    await mongo.connect();
    const schemaSql = await readFile(new URL("../db/local-postgres.sql", import.meta.url), "utf8");
    await client.query(schemaSql);

    await client.query("begin");
    const userIds = await seedUsers(client);
    const placeIds = await seedPlaces(client, userIds);
    const transportProviderIds = await seedTransportProviders(client);
    const transportHubIds = await seedTransportHubs(client);
    const activityIds = await seedActivityCatalog(client, placeIds);
    const tripIds = await seedTrips(client, userIds, placeIds, activityIds, transportProviderIds, transportHubIds);
    await seedMongo(mongo.db(process.env.MONGODB_DB_NAME ?? "travel_planner"), userIds, tripIds);
    await client.query("commit");

    const counts = await countTables(client, [
      "users",
      "profiles",
      "trips",
      "trip_members",
      "places",
      "activity_catalog",
      "trip_activities",
      "trip_checklist_items",
      "transport_segments",
      "transport_bookings",
      "transport_price_insights",
      "accommodations",
      "expenses",
      "expense_splits",
      "bill_uploads",
    ]);
    console.info(JSON.stringify({ status: "ok", seeded: "demo-system", counts }, null, 2));
  } catch (error) {
    await client.query("rollback").catch(() => undefined);
    throw error;
  } finally {
    await mongo.close().catch(() => undefined);
    await client.end();
  }
}

async function seedUsers(client) {
  const ids = new Map();
  for (const [email, fullName, homeCity, prefs] of users) {
    const user = await one(client,
      `insert into users (email, password_hash, full_name, provider)
       values ($1, $2, $3, 'local')
       on conflict (email) do update set full_name = excluded.full_name, updated_at = now()
       returning id`,
      [email, demoPasswordHash, fullName]
    );
    ids.set(email, user.id);
    await client.query(
      `insert into profiles (user_id, display_name, home_city_slug, travel_preferences)
       values ($1, $2, $3, $4)
       on conflict (user_id) do update set
         display_name = excluded.display_name,
         home_city_slug = excluded.home_city_slug,
         travel_preferences = excluded.travel_preferences,
         updated_at = now()`,
      [user.id, fullName, homeCity, prefs]
    );
  }

  await client.query(
    `insert into search_drafts (user_id, email_hint, prompt_text, search_payload, status)
     values
       ($1, 'host@horizon.local', 'Tôi muốn đi Đà Nẵng và Hội An 4 ngày, có cafe đẹp và ăn địa phương', $2, 'pending'),
       ($3, 'linh@horizon.local', 'Nhóm mình muốn đi Hà Nội Ninh Bình, chia tiền minh bạch', $4, 'pending')`,
    [
      ids.get("host@horizon.local"),
      { cities: ["da-nang", "hoi-an"], num_days: 4, budget: 8000000, currency: "VND" },
      ids.get("linh@horizon.local"),
      { cities: ["ha-noi", "ninh-binh"], num_days: 4, budget: 7000000, currency: "VND" },
    ]
  );
  return ids;
}

async function seedPlaces(client, userIds) {
  const ids = new Map();
  for (const [key, city, canonical, current, type, category, address, lat, lon, tags, priceLevel, rating, quality] of places) {
    const place = await upsertPlace(client, {
      city,
      canonical,
      current,
      type,
      category,
      address,
      lat,
      lon,
      tags,
      priceLevel,
      rating,
      quality,
      createdBy: userIds.get("host@horizon.local"),
    });
    ids.set(key, place.id);
    await client.query(
      `insert into place_locations (place_id, address, lat, lon, valid_from, is_current)
       select $1, $2, $3, $4, current_date - interval '1 year', true
       where not exists (
         select 1 from place_locations where place_id = $1 and address = $2 and is_current = true
       )`,
      [place.id, address, lat, lon]
    );
    await client.query(
      `insert into place_price_history (place_id, price_type, price, currency, observed_at, source, confidence_score)
       values ($1, $2, $3, 'VND', now() - ($4 || ' days')::interval, 'internal_seed', 0.85)`,
      [place.id, type === "hotel" || type === "homestay" ? "room_night" : type === "cafe" ? "coffee" : type === "activity" || type === "attraction" ? "entrance_ticket" : "average_bill", priceLevel * 75000, priceLevel * 5]
    );
  }

  await client.query(
    `insert into place_aliases (place_id, name, alias_type, valid_from, valid_to)
     values
       ($1, 'Mót Hội An Old Name', 'old_name', current_date - interval '3 years', current_date - interval '1 year'),
       ($2, 'Cộng Cà Phê Riverside', 'alternate_name', current_date - interval '2 years', null)
     on conflict do nothing`,
    [ids.get("mot-hoi-an"), ids.get("cong-caphe-danang")]
  );
  await client.query(
    `insert into place_change_signals (place_id, candidate_name, candidate_address, signal_type, source, confidence_score, evidence, status)
     values
       ($1, 'Mót Hội An', '150 Trần Phú, Hội An', 'price_changed', 'user_bill', 0.88, $2, 'accepted'),
       ($3, 'Old River Coffee', '98-96 Bạch Đằng, Đà Nẵng', 'renamed', 'user_input', 0.62, $4, 'pending'),
       ($5, 'Hoi An Lantern Homestay', 'New branch near An Bang, Hội An', 'moved', 'crawler', 0.57, $6, 'pending')`,
    [
      ids.get("mot-hoi-an"),
      { old_average_bill: 45000, new_average_bill: 65000 },
      ids.get("cong-caphe-danang"),
      { reported_by: "linh@horizon.local" },
      ids.get("hoi-an-lantern-homestay"),
      { source: "mock crawler" },
    ]
  );
  return ids;
}

async function seedActivityCatalog(client, placeIds) {
  const activities = [
    ["basket_boat", placeIds.get("basket-boat-cam-thanh"), "hoi-an", "Basket boat in Cam Thanh", "eco-tour", ["river", "family"], 300000, 90],
    ["lantern_walk", placeIds.get("mot-hoi-an"), "hoi-an", "Hoi An lantern walking route", "walking", ["old-town", "photo"], 0, 120],
    ["my_khe_sunrise", placeIds.get("my-khe-beach"), "da-nang", "Sunrise walk at My Khe Beach", "nature", ["beach", "sunrise"], 0, 60],
    ["temple_literature", placeIds.get("temple-literature"), "ha-noi", "Visit Temple of Literature", "heritage", ["culture", "history"], 70000, 90],
    ["trang_an_boat", placeIds.get("trang-an"), "ninh-binh", "Trang An boat tour", "boat-tour", ["heritage", "river"], 250000, 180],
    ["mua_cave_hike", placeIds.get("mua-cave"), "ninh-binh", "Mua Cave viewpoint hike", "hike", ["viewpoint", "nature"], 100000, 120],
    ["coffee_workshop", placeIds.get("la-viet-coffee"), "da-lat", "Coffee tasting workshop", "coffee", ["coffee", "workshop"], 180000, 90],
    ["hon_mun_snorkeling", placeIds.get("hon-mun-snorkeling"), "nha-trang", "Hon Mun snorkeling half-day", "snorkeling", ["island", "sea"], 650000, 240],
    ["po_nagar_visit", placeIds.get("po-nagar"), "nha-trang", "Po Nagar Cham Towers visit", "heritage", ["culture", "history"], 30000, 75],
    ["cai_rang_boat", placeIds.get("cai-rang-market"), "can-tho", "Cai Rang sunrise boat market", "mekong", ["river", "food"], 350000, 180],
    ["fansipan_cable", placeIds.get("fansipan-cable-car"), "sa-pa", "Fansipan cable car and summit", "mountain", ["viewpoint", "nature"], 850000, 240],
    ["phu_quoc_starfish", placeIds.get("starfish-beach"), "phu-quoc", "Starfish Beach slow afternoon", "beach", ["family", "relax"], 0, 180],
  ];
  const ids = new Map();
  for (const [key, placeId, city, title, category, tags, cost, duration] of activities) {
    const row = await upsertBySelect(client,
      "select id from activity_catalog where city_slug = $1 and lower(title) = lower($2) limit 1",
      [city, title],
      `insert into activity_catalog (place_id, city_slug, title, category, tags, estimated_cost, duration_minutes, source, popularity_score, quality_score)
       values ($1, $2, $3, $4, $5, $6, $7, 'internal_seed', 0.8, 0.8)
       returning id`,
      [placeId, city, title, category, tags, cost, duration],
      `update activity_catalog set place_id = $2, category = $3, tags = $4, estimated_cost = $5, duration_minutes = $6, updated_at = now()
       where id = $1 returning id`,
      [placeId, category, tags, cost, duration]
    );
    ids.set(key, row.id);
  }
  return ids;
}

async function seedTransportProviders(client) {
  const ids = new Map();
  for (const [mode, code, name, country] of transportProviders) {
    const row = await one(client,
      `insert into transport_providers (mode, code, name, country)
       values ($1, $2, $3, $4)
       on conflict (mode, code) do update set name = excluded.name, country = excluded.country
       returning id`,
      [mode, code, name, country]
    );
    ids.set(`${mode}:${code}`, row.id);
  }
  return ids;
}

async function seedTransportHubs(client) {
  const ids = new Map();
  for (const [type, code, name, city] of transportHubs) {
    const row = await one(client,
      `insert into transport_hubs (type, hub_code, name, city_slug, country)
       values ($1, $2, $3, $4, 'VN')
       on conflict (type, hub_code) do update set name = excluded.name, city_slug = excluded.city_slug
       returning id`,
      [type, code, name, city]
    );
    ids.set(`${type}:${code}`, row.id);
    ids.set(code, row.id);
  }
  return ids;
}

async function seedTrips(client, usersByEmail, placeIds, activityIds, transportProviderIds, transportHubIds) {
  const host = usersByEmail.get("host@horizon.local");
  const linh = usersByEmail.get("linh@horizon.local");
  const khoa = usersByEmail.get("khoa@horizon.local");
  const minh = usersByEmail.get("minh@horizon.local");
  const an = usersByEmail.get("an@horizon.local");
  const viewer = usersByEmail.get("viewer@horizon.local");
  const trips = new Map();

  const danangTrip = await upsertTrip(client, host, "Da Nang & Hoi An food-culture group trip", "da-nang", "2026-08-12", "2026-08-15", 18000000);
  trips.set("danang", danangTrip.id);
  const hanoiTrip = await upsertTrip(client, linh, "Ha Noi - Ninh Binh heritage split-bill test", "ha-noi", "2026-09-05", "2026-09-08", 14000000);
  trips.set("hanoi", hanoiTrip.id);
  const dalatTrip = await upsertTrip(client, minh, "Da Lat cafe and homestay discovery", "da-lat", "2026-10-10", "2026-10-12", 9000000);
  trips.set("dalat", dalatTrip.id);
  const nhaTrangTrip = await upsertTrip(client, an, "Nha Trang family beach and snorkeling", "nha-trang", "2026-11-03", "2026-11-06", 16000000);
  trips.set("nha-trang", nhaTrangTrip.id);
  const phuQuocTrip = await upsertTrip(client, khoa, "Phu Quoc flexible flight-price watch", "phu-quoc", "2026-12-18", "2026-12-22", 22000000);
  trips.set("phu-quoc", phuQuocTrip.id);

  for (const [tripId, members] of [
    [danangTrip.id, [[host, "host"], [linh, "contributor"], [khoa, "contributor"], [viewer, "viewer"]]],
    [hanoiTrip.id, [[linh, "host"], [host, "co_host"], [an, "contributor"], [viewer, "viewer"]]],
    [dalatTrip.id, [[minh, "host"], [an, "contributor"]]],
    [nhaTrangTrip.id, [[an, "host"], [host, "viewer"], [minh, "contributor"]]],
    [phuQuocTrip.id, [[khoa, "host"], [linh, "co_host"], [viewer, "viewer"]]],
  ]) {
    for (const [userId, role] of members) {
      await client.query(
        `insert into trip_members (trip_id, user_id, role, status, invited_by_user_id, joined_at)
         values ($1, $2, $3, 'active', $4, now())
         on conflict (trip_id, user_id) do update set role = excluded.role, status = 'active'`,
        [tripId, userId, role, host]
      );
    }
  }

  const dayIds = new Map();
  for (const [tripKey, tripId, startDate, count] of [
    ["danang", danangTrip.id, "2026-08-12", 4],
    ["hanoi", hanoiTrip.id, "2026-09-05", 4],
    ["dalat", dalatTrip.id, "2026-10-10", 3],
    ["nha-trang", nhaTrangTrip.id, "2026-11-03", 4],
    ["phu-quoc", phuQuocTrip.id, "2026-12-18", 5],
  ]) {
    for (let i = 1; i <= count; i += 1) {
      const row = await one(client,
        `insert into trip_days (trip_id, day_index, date, title)
         values ($1, $2, $3::date + ($2 - 1), $4)
         on conflict (trip_id, day_index) do update set date = excluded.date, title = excluded.title
         returning id`,
        [tripId, i, startDate, `Day ${i}`]
      );
      dayIds.set(`${tripKey}-${i}`, row.id);
    }
  }

  const tripActivityIds = new Map();
  const tripActivities = [
    ["danang-basket", danangTrip.id, dayIds.get("danang-2"), placeIds.get("basket-boat-cam-thanh"), activityIds.get("basket_boat"), "Basket boat in Cam Thanh", "approved", host, 300000],
    ["danang-mykhe", danangTrip.id, dayIds.get("danang-1"), placeIds.get("my-khe-beach"), activityIds.get("my_khe_sunrise"), "Sunrise at My Khe Beach", "approved", linh, 0],
    ["danang-madame", danangTrip.id, dayIds.get("danang-1"), placeIds.get("madame-lan"), null, "Dinner at Madame Lan", "approved", khoa, 900000],
    ["hanoi-temple", hanoiTrip.id, dayIds.get("hanoi-1"), placeIds.get("temple-literature"), activityIds.get("temple_literature"), "Temple of Literature visit", "approved", linh, 70000],
    ["hanoi-trangan", hanoiTrip.id, dayIds.get("hanoi-3"), placeIds.get("trang-an"), activityIds.get("trang_an_boat"), "Trang An boat tour", "approved", an, 250000],
    ["dalat-coffee", dalatTrip.id, dayIds.get("dalat-2"), placeIds.get("la-viet-coffee"), activityIds.get("coffee_workshop"), "La Viet coffee tasting", "pending", an, 180000],
    ["nhatrang-honmun", nhaTrangTrip.id, dayIds.get("nha-trang-2"), placeIds.get("hon-mun-snorkeling"), activityIds.get("hon_mun_snorkeling"), "Hon Mun snorkeling half-day", "approved", an, 650000],
    ["nhatrang-ponagar", nhaTrangTrip.id, dayIds.get("nha-trang-1"), placeIds.get("po-nagar"), activityIds.get("po_nagar_visit"), "Po Nagar Cham Towers visit", "approved", minh, 30000],
    ["phuquoc-starfish", phuQuocTrip.id, dayIds.get("phu-quoc-3"), placeIds.get("starfish-beach"), activityIds.get("phu_quoc_starfish"), "Starfish Beach slow afternoon", "pending", linh, 0],
    ["phuquoc-nightmarket", phuQuocTrip.id, dayIds.get("phu-quoc-1"), placeIds.get("phu-quoc-night-market"), null, "Phu Quoc night market seafood", "approved", khoa, 850000],
  ];
  for (const [key, tripId, dayId, placeId, catalogId, title, approval, creator, price] of tripActivities) {
    const row = await upsertBySelect(client,
      "select id from trip_activities where trip_id = $1 and title = $2 limit 1",
      [tripId, title],
      `insert into trip_activities (
         trip_id, trip_day_id, place_id, activity_catalog_id, title, status, approval_status,
         created_by_user_id, updated_by_user_id, approved_by_user_id, place_name_snapshot, address_snapshot, price_snapshot
       )
       values ($1, $2, $3, $4, $5, 'planned', $6, $7, $7, $8, $9, $10, $11)
       returning id`,
      [tripId, dayId, placeId, catalogId, title, approval, creator, approval === "approved" ? host : null, title, "demo address snapshot", price],
      `update trip_activities set trip_day_id = $2, place_id = $3, approval_status = $4, updated_at = now()
       where id = $1 returning id`,
      [dayId, placeId, approval]
    );
    tripActivityIds.set(key, row.id);
  }

  const danangFlightTransport = await upsertBySelect(client,
    "select id from transport_segments where trip_id = $1 and service_number = 'VN136' limit 1",
    [danangTrip.id],
    `insert into transport_segments (
       trip_id, mode, provider_id, from_hub_id, to_hub_id, from_label, to_label,
       service_number, departure_time, arrival_time, service_class, status, created_by_user_id
     )
     values ($1, 'flight', $2, $3, $4, 'SGN', 'DAD', 'VN136', '2026-08-12T06:30:00+07:00', '2026-08-12T07:50:00+07:00', 'economy', 'booked', $5)
     returning id`,
    [danangTrip.id, transportProviderIds.get("flight:VN"), transportHubIds.get("SGN"), transportHubIds.get("DAD"), host],
    `update transport_segments set provider_id = $2, from_hub_id = $3, to_hub_id = $4, status = 'booked'
     where id = $1 returning id`,
    [transportProviderIds.get("flight:VN"), transportHubIds.get("SGN"), transportHubIds.get("DAD")]
  );
  const danangTrainTransport = await upsertBySelect(client,
    "select id from transport_segments where trip_id = $1 and service_number = 'SE2-DEMO' limit 1",
    [danangTrip.id],
    `insert into transport_segments (
       trip_id, mode, provider_id, from_hub_id, to_hub_id, from_label, to_label,
       service_number, departure_time, arrival_time, service_class, status, created_by_user_id
     )
     values ($1, 'train', $2, $3, $4, 'Saigon Railway Station', 'Da Nang Railway Station', 'SE2-DEMO', '2026-08-11T19:30:00+07:00', '2026-08-12T12:20:00+07:00', 'sleeper', 'planned', $5)
     returning id`,
    [danangTrip.id, transportProviderIds.get("train:VNR"), transportHubIds.get("SG"), transportHubIds.get("DN"), linh],
    `update transport_segments set provider_id = $2, from_hub_id = $3, to_hub_id = $4, status = 'planned'
     where id = $1 returning id`,
    [transportProviderIds.get("train:VNR"), transportHubIds.get("SG"), transportHubIds.get("DN")]
  );
  await upsertBySelect(client,
    "select id from transport_segments where trip_id = $1 and service_number = 'FERRY-CAMKIM-01' limit 1",
    [danangTrip.id],
    `insert into transport_segments (
       trip_id, mode, provider_id, from_hub_id, to_hub_id, from_label, to_label,
       service_number, departure_time, arrival_time, service_class, status, created_by_user_id
     )
     values ($1, 'ferry', $2, $3, $4, 'Bach Dang Pier', 'Cam Kim Pier', 'FERRY-CAMKIM-01', '2026-08-13T08:00:00+07:00', '2026-08-13T08:25:00+07:00', 'standard', 'planned', $5)
     returning id`,
    [danangTrip.id, transportProviderIds.get("ferry:HANRIVER"), transportHubIds.get("BDP"), transportHubIds.get("CKP"), khoa],
    `update transport_segments set provider_id = $2, from_hub_id = $3, to_hub_id = $4, status = 'planned'
     where id = $1 returning id`,
    [transportProviderIds.get("ferry:HANRIVER"), transportHubIds.get("BDP"), transportHubIds.get("CKP")]
  );
  const transportFlightBooking = await upsertBySelect(client,
    "select id from transport_bookings where booking_reference = 'VN-DEMO-136' limit 1",
    [],
    `insert into transport_bookings (trip_id, user_id, segment_id, provider_id, booking_provider, booking_reference, base_price, taxes_and_fees, total_price, purchased_at, booking_status, created_by_user_id)
     values ($1, $2, $3, $4, 'Vietnam Airlines', 'VN-DEMO-136', 1650000, 220000, 1870000, now() - interval '12 days', 'purchased', $2)
     returning id`,
    [danangTrip.id, host, danangFlightTransport.id, transportProviderIds.get("flight:VN")],
    `update transport_bookings set segment_id = $2, provider_id = $3, base_price = 1650000, taxes_and_fees = 220000,
       total_price = 1870000, booking_status = 'purchased'
     where id = $1 returning id`,
    [danangFlightTransport.id, transportProviderIds.get("flight:VN")]
  );
  await upsertBySelect(client,
    "select id from transport_bookings where booking_reference = 'VNR-DEMO-SE2' limit 1",
    [],
    `insert into transport_bookings (trip_id, user_id, segment_id, provider_id, booking_provider, booking_reference, base_price, taxes_and_fees, total_price, booking_status, created_by_user_id)
     values ($1, $2, $3, $4, 'Vietnam Railways', 'VNR-DEMO-SE2', 820000, 0, 820000, 'held', $2)
     returning id`,
    [danangTrip.id, linh, danangTrainTransport.id, transportProviderIds.get("train:VNR")],
    `update transport_bookings set segment_id = $2, provider_id = $3, base_price = 820000, total_price = 820000
     where id = $1 returning id`,
    [danangTrainTransport.id, transportProviderIds.get("train:VNR")]
  );

  for (const [mode, from, to, provider, serviceClass, daysOut, price] of [
    ["flight", "SGN", "DAD", "flight:VN", "economy", 28, 1870000],
    ["flight", "SGN", "DAD", "flight:VJ", "economy", 35, 1350000],
    ["train", "SG", "DN", "train:VNR", "sleeper", 21, 820000],
    ["bus", "MDE", "DL", "bus:FUTA", "seat", 10, 320000],
    ["ferry", "RG", "BTH", "ferry:PQF", "standard", 14, 390000],
  ]) {
    await client.query(
      `insert into transport_price_snapshots (mode, route_from_hub_id, route_to_hub_id, provider_id, service_class, departure_date, observed_at, price, source)
       values ($1, $2, $3, $4, $5, current_date + ($6 || ' days')::interval, now(), $7, 'internal_seed')`,
      [mode, transportHubIds.get(from), transportHubIds.get(to), transportProviderIds.get(provider), serviceClass, daysOut, price]
    );
  }
  for (const [mode, from, to, provider, serviceClass, month, cheapest, average, threshold, start, end, recommendation, confidence] of [
    ["flight", "SGN", "DAD", "flight:VN", "economy", 8, 1350000, 1900000, 2600000, 30, 45, "SGN -> DAD thường tốt hơn khi mua trước 30-45 ngày, so sánh thêm tàu nếu lịch linh hoạt.", 0.76],
    ["train", "SG", "DN", "train:VNR", "sleeper", 8, 820000, 1100000, 1500000, 14, 30, "Tàu giường nằm đi Đà Nẵng thường ổn khi đặt trước 2-4 tuần, phù hợp nhóm muốn tiết kiệm.", 0.68],
    ["bus", "MDE", "DL", "bus:FUTA", "seat", 10, 320000, 420000, 550000, 7, 21, "Xe khách đi Đà Lạt có giá ổn định, nên đặt ghế sớm vào cuối tuần.", 0.64],
    ["ferry", "RG", "BTH", "ferry:PQF", "standard", 12, 390000, 470000, 650000, 10, 20, "Tàu cao tốc Phú Quốc nên kiểm tra thời tiết và đặt sớm mùa lễ.", 0.62],
  ]) {
    await upsertBySelect(client,
      "select id from transport_price_insights where mode = $1 and route_from_hub_id = $2 and route_to_hub_id = $3 and service_class = $4 and month = $5 limit 1",
      [mode, transportHubIds.get(from), transportHubIds.get(to), serviceClass, month],
      `insert into transport_price_insights (
         mode, route_from_hub_id, route_to_hub_id, provider_id, service_class, month,
         cheapest_observed_price, average_price, expensive_threshold, cheap_window_start,
         cheap_window_end, recommendation, confidence_score
       )
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       returning id`,
      [mode, transportHubIds.get(from), transportHubIds.get(to), transportProviderIds.get(provider), serviceClass, month, cheapest, average, threshold, start, end, recommendation, confidence],
      `update transport_price_insights set provider_id = $2, cheapest_observed_price = $3, average_price = $4,
         expensive_threshold = $5, cheap_window_start = $6, cheap_window_end = $7,
         recommendation = $8, confidence_score = $9, updated_at = now()
       where id = $1 returning id`,
      [transportProviderIds.get(provider), cheapest, average, threshold, start, end, recommendation, confidence]
    );
  }

  const accom = await upsertBySelect(client,
    "select id from accommodations where booking_reference = 'HOTEL-DAD-001' limit 1",
    [],
    `insert into accommodations (trip_id, place_id, check_in_date, check_out_date, room_type, guests, nights, price_per_night, total_price, booking_provider, booking_reference, booking_status, approval_status, created_by_user_id, approved_by_user_id, locked_at)
     values ($1, $2, '2026-08-12', '2026-08-15', 'Family room river view', 4, 3, 950000, 2850000, 'Booking Demo', 'HOTEL-DAD-001', 'booked', 'approved', $3, $3, now())
     returning id`,
    [danangTrip.id, placeIds.get("hotel-danang-river"), host],
    `update accommodations set total_price = 2850000, booking_status = 'booked', approval_status = 'approved'
     where id = $1 returning id`,
    []
  );
  const bill = await upsertBySelect(client,
    "select id from bill_uploads where storage_url = 's3://demo-bills/madame-lan-dinner.jpg' limit 1",
    [],
    `insert into bill_uploads (trip_id, uploaded_by_user_id, place_id, activity_id, storage_url, status, total_amount, currency, bill_date)
     values ($1, $2, $3, $4, 's3://demo-bills/madame-lan-dinner.jpg', 'confirmed', 980000, 'VND', now() - interval '2 days')
     returning id`,
    [danangTrip.id, khoa, placeIds.get("madame-lan"), tripActivityIds.get("danang-madame")],
    `update bill_uploads set status = 'confirmed', total_amount = 980000, place_id = $2, activity_id = $3
     where id = $1 returning id`,
    [placeIds.get("madame-lan"), tripActivityIds.get("danang-madame")]
  );
  await client.query("delete from bill_line_items where bill_upload_id = $1", [bill.id]);
  for (const [name, qty, unit, amount, category] of [
    ["Mì Quảng", 4, 85000, 340000, "food"],
    ["Bánh tráng cuốn", 2, 160000, 320000, "food"],
    ["Nước sả", 4, 45000, 180000, "drink"],
    ["Service charge", 1, 140000, 140000, "service"],
  ]) {
    await client.query(
      `insert into bill_line_items (bill_upload_id, name, quantity, unit_price, amount, category, confidence_score)
       values ($1, $2, $3, $4, $5, $6, 0.88)`,
      [bill.id, name, qty, unit, amount, category]
    );
  }

  const expenseRows = [
    ["Transport: SGN -> DAD flight tickets", danangTrip.id, null, null, transportFlightBooking.id, null, null, host, 1870000, "transport", host],
    ["Dinner at Madame Lan", danangTrip.id, tripActivityIds.get("danang-madame"), placeIds.get("madame-lan"), null, null, bill.id, khoa, 980000, "food", khoa],
    ["Family room river hotel", danangTrip.id, null, placeIds.get("hotel-danang-river"), null, accom.id, null, host, 2850000, "accommodation", host],
    ["Basket boat tickets", danangTrip.id, tripActivityIds.get("danang-basket"), placeIds.get("basket-boat-cam-thanh"), null, null, null, linh, 1200000, "activity", linh],
    ["Trang An boat tickets", hanoiTrip.id, tripActivityIds.get("hanoi-trangan"), placeIds.get("trang-an"), null, null, null, an, 1000000, "activity", an],
    ["Giang Cafe morning coffee", hanoiTrip.id, null, placeIds.get("giang-cafe"), null, null, null, host, 180000, "food", host],
    ["La Viet coffee workshop", dalatTrip.id, tripActivityIds.get("dalat-coffee"), placeIds.get("la-viet-coffee"), null, null, null, an, 360000, "activity", an],
    ["Hon Mun snorkeling package", nhaTrangTrip.id, tripActivityIds.get("nhatrang-honmun"), placeIds.get("hon-mun-snorkeling"), null, null, null, an, 1950000, "activity", an],
    ["Sailing Club dinner", nhaTrangTrip.id, null, placeIds.get("sailing-club-nhatrang"), null, null, null, minh, 1450000, "food", minh],
    ["Phu Quoc night market seafood", phuQuocTrip.id, tripActivityIds.get("phuquoc-nightmarket"), placeIds.get("phu-quoc-night-market"), null, null, null, khoa, 1320000, "food", khoa],
  ];
  for (const [title, tripId, activityId, placeId, transportBookingId, accommodationId, billId, paidBy, amount, type, creator] of expenseRows) {
    const expense = await upsertBySelect(client,
      "select id from expenses where trip_id = $1 and title = $2 limit 1",
      [tripId, title],
      `insert into expenses (trip_id, activity_id, place_id, transport_booking_id, accommodation_id, bill_upload_id, paid_by_user_id, title, amount, expense_type, approval_status, created_by_user_id, approved_by_user_id, locked_at)
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'approved', $11, $12, now())
       returning id`,
      [tripId, activityId, placeId, transportBookingId, accommodationId, billId, paidBy, title, amount, type, creator, host],
      `update expenses set activity_id = $2, place_id = $3, transport_booking_id = $4,
         accommodation_id = $5, bill_upload_id = $6, paid_by_user_id = $7, amount = $8,
         expense_type = $9, approval_status = 'approved', approved_by_user_id = $10,
         locked_at = coalesce(locked_at, now()), updated_at = now()
       where id = $1 returning id`,
      [activityId, placeId, transportBookingId, accommodationId, billId, paidBy, amount, type, host]
    );
    await client.query("delete from expense_items where expense_id = $1", [expense.id]);
    await client.query(
      `insert into expense_items (expense_id, activity_id, place_id, title, quantity, unit_price, amount)
       values ($1, $2, $3, $4, 1, $5, $5)`,
      [expense.id, activityId, placeId, title, amount]
    );
    const splitUsers = tripId === hanoiTrip.id
      ? [linh, host, an, viewer]
      : tripId === dalatTrip.id
        ? [minh, an]
        : tripId === nhaTrangTrip.id
          ? [an, host, minh]
          : tripId === phuQuocTrip.id
            ? [khoa, linh, viewer]
            : [host, linh, khoa, viewer];
    for (const userId of splitUsers) {
      await client.query(
        `insert into expense_splits (expense_id, user_id, share_amount, share_percent, status)
         values ($1, $2, $3, 25, 'pending')
         on conflict (expense_id, user_id) do update set share_amount = excluded.share_amount, share_percent = excluded.share_percent`,
        [expense.id, userId, Math.round(Number(amount) / splitUsers.length)]
      );
    }
  }

  await client.query(
    `insert into trip_change_requests (trip_id, target_type, target_id, requested_by_user_id, change_payload, reason, status)
     values ($1, 'expense', $2, $3, $4, 'Contributor reports one member did not join dinner', 'pending')`,
    [danangTrip.id, bill.id, linh, { remove_member_email: "viewer@horizon.local" }]
  );
  await client.query(
    `insert into trip_audit_logs (trip_id, actor_user_id, action, target_type, target_id, after_snapshot)
     values
       ($1, $2, 'expense.approved', 'bill_upload', $3, $4),
       ($1, $5, 'activity.created', 'trip_activity', $6, $7)`,
    [danangTrip.id, host, bill.id, { total: 980000 }, linh, tripActivityIds.get("danang-basket"), { title: "Basket boat tickets" }]
  );

  await seedChecklist(client, [
    [danangTrip.id, "Buy SGN -> DAD transport tickets", "transport", "done", "2026-07-28", host, null, null, danangFlightTransport.id],
    [danangTrip.id, "Compare sleeper train backup option", "transport", "todo", "2026-08-01", linh, null, null, danangTrainTransport.id],
    [danangTrip.id, "Confirm river-view family room", "hotel", "done", "2026-08-01", host, null, accom.id, null],
    [danangTrip.id, "Book Cam Thanh basket boat", "activity", "in_progress", "2026-08-05", linh, tripActivityIds.get("danang-basket"), null, null],
    [danangTrip.id, "Review Madame Lan dinner bill split", "payment", "todo", "2026-08-16", khoa, tripActivityIds.get("danang-madame"), null, null],
    [hanoiTrip.id, "Buy Trang An boat tickets", "activity", "todo", "2026-08-28", an, tripActivityIds.get("hanoi-trangan"), null, null],
    [nhaTrangTrip.id, "Reserve snorkeling package", "activity", "in_progress", "2026-10-20", an, tripActivityIds.get("nhatrang-honmun"), null, null],
    [phuQuocTrip.id, "Watch transport prices for SGN -> PQC", "transport", "todo", "2026-11-15", khoa, null, null, null],
  ]);

  await client.query(
    `insert into user_place_submissions (user_id, trip_id, raw_name, raw_type, raw_address, raw_notes, raw_price, raw_metadata, normalized_place_id, status)
     values
       ($1, $2, 'Old River Coffee', 'cafe', '98-96 Bạch Đằng, Đà Nẵng', 'Có vẻ đổi tên từ Cộng Cà Phê', 65000, $3, $4, 'pending'),
       ($5, $6, 'Quán bún nhỏ gần khách sạn', 'restaurant', 'Hàng Bạc, Hà Nội', 'Bill khoảng 120k/người', 120000, $7, null, 'pending')`,
    [linh, danangTrip.id, { signal: "renamed" }, placeIds.get("cong-caphe-danang"), an, hanoiTrip.id, { source: "manual" }]
  );

  return trips;
}

async function seedChecklist(client, items) {
  for (const [tripId, title, category, status, dueDate, assignedTo, activityId, accommodationId, transportSegmentId] of items) {
    await client.query(
      `insert into trip_checklist_items (
         trip_id, title, category, status, due_date, assigned_to_user_id,
         related_activity_id, related_accommodation_id, related_transport_segment_id, created_by_user_id
       )
       values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $6)
       on conflict do nothing`,
      [tripId, title, category, status, dueDate, assignedTo, activityId, accommodationId, transportSegmentId]
    );
  }
}

async function seedMongo(db, userIds, tripIds) {
  const now = new Date();
  await db.collection("prompt_text_events").updateOne(
    { user_id: userIds.get("host@horizon.local"), cache_key: "demo-da-nang-hoi-an-culture" },
    {
      $set: {
        user_id: userIds.get("host@horizon.local"),
        cache_key: "demo-da-nang-hoi-an-culture",
        cities: ["da-nang", "hoi-an"],
        city_names: ["Da Nang", "Hoi An"],
        raw_prompt_text: "Tôi muốn đi Đà Nẵng và Hội An 4 ngày, cafe đẹp, ăn địa phương, có chia tiền nhóm.",
        analysis_status: "analyzed",
        cluster_key: "demo-cluster-dad-han-food",
        prompt_cluster: { intent_tags: ["food", "culture", "group-expense"], duration_bucket: "standard-week" },
        created_at: now,
        updated_at: now,
        expires_at: new Date(now.getTime() + 90 * 86400000),
      },
    },
    { upsert: true }
  );
  await db.collection("prompt_search_clusters").updateOne(
    { cluster_key: "demo-cluster-dad-han-food" },
    {
      $set: {
        cluster_key: "demo-cluster-dad-han-food",
        city_slugs: ["da-nang", "hoi-an"],
        city_names: ["Da Nang", "Hoi An"],
        trip_style: "culture",
        intent_tags: ["food", "culture", "group-expense"],
        request_count: 12,
        last_used_at: now,
      },
      $setOnInsert: { created_at: now },
    },
    { upsert: true }
  );
  await db.collection("ocr_raw_documents").updateOne(
    { bill_upload_id: "demo-madame-lan-bill" },
    {
      $set: {
        bill_upload_id: "demo-madame-lan-bill",
        trip_id: tripIds.get("danang"),
        raw_ocr_text: "MADAME LAN\\nMi Quang x4 340000\\nBanh trang cuon x2 320000\\nNuoc sa x4 180000\\nService 140000\\nTotal 980000",
        detected_language: "vi",
        confidence: 0.88,
        status: "parsed",
        created_at: now,
      },
    },
    { upsert: true }
  );
  await db.collection("place_normalization_jobs").updateOne(
    { submission_id: "demo-old-river-coffee" },
    {
      $set: {
        submission_id: "demo-old-river-coffee",
        raw_name: "Old River Coffee",
        candidate_place_name: "Cong Caphe Da Nang",
        status: "pending_review",
        confidence_score: 0.62,
        created_at: now,
      },
    },
    { upsert: true }
  );
}

async function upsertTrip(client, owner, title, city, startDate, endDate, budget) {
  return upsertBySelect(client,
    "select id from trips where owner_user_id = $1 and title = $2 limit 1",
    [owner, title],
    `insert into trips (owner_user_id, title, description, primary_city_slug, start_date, end_date, status, visibility, budget)
     values ($1, $2, 'Seeded full-flow demo trip', $3, $4, $5, 'planning', 'shared', $6)
     returning id`,
    [owner, title, city, startDate, endDate, budget],
    `update trips set primary_city_slug = $2, start_date = $3, end_date = $4, budget = $5, updated_at = now()
     where id = $1 returning id`,
    [city, startDate, endDate, budget]
  );
}

async function upsertPlace(client, input) {
  return upsertBySelect(client,
    "select id from places where city_slug = $1 and lower(current_name) = lower($2) and type = $3 limit 1",
    [input.city, input.current, input.type],
    `insert into places (
       city_slug, canonical_name, current_name, type, category, normalized_address, lat, lon,
       tags, price_level, average_rating, quality_score, freshness_score, source, status,
       last_verified_at, created_by_user_id
     )
     values ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, 0.92, 'internal_seed', 'active', now(), $13)
     returning id`,
    [input.city, input.canonical, input.current, input.type, input.category, input.address, input.lat, input.lon, input.tags, input.priceLevel, input.rating, input.quality, input.createdBy],
    `update places set category = $2, normalized_address = $3, lat = $4, lon = $5, tags = $6,
       price_level = $7, average_rating = $8, quality_score = $9, freshness_score = 0.92,
       last_verified_at = now(), updated_at = now()
     where id = $1 returning id`,
    [input.category, input.address, input.lat, input.lon, input.tags, input.priceLevel, input.rating, input.quality]
  );
}

async function upsertBySelect(client, selectSql, selectParams, insertSql, insertParams, updateSql, updateParams) {
  const existing = await client.query(selectSql, selectParams);
  if (existing.rows[0]?.id) {
    return one(client, updateSql, [existing.rows[0].id, ...updateParams]);
  }
  return one(client, insertSql, insertParams);
}

async function one(client, sql, params) {
  const result = await client.query(sql, params);
  return result.rows[0];
}

async function countTables(client, tables) {
  const counts = {};
  for (const table of tables) {
    const row = await one(client, `select count(*)::int as count from ${table}`, []);
    counts[table] = row.count;
  }
  return counts;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const key = crypto.scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${key}`;
}

function splitCsv(value) {
  return (value ?? "")
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);
}

function unique(values) {
  return [...new Set(values.filter(Boolean))];
}
