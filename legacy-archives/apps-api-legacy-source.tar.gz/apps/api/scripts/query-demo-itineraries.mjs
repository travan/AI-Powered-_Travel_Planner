import { config } from "dotenv";
import { createClient } from "@supabase/supabase-js";

// Load environment variables from .env file
config({ path: "../../../.env" });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
const placeholderUrls = ["https://example.supabase.co", "service-role-placeholder"];

if (!supabaseUrl || !supabaseKey) {
  console.warn("SUPABASE_URL or SUPABASE_SERVICE_KEY is missing. Skipping query.");
  process.exit(0);
}

if (placeholderUrls.includes(supabaseUrl) || placeholderUrls.includes(supabaseKey)) {
  console.warn("Supabase env values are placeholder values. Skipping query.");
  process.exit(0);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false },
});

const { data, error } = await supabase
  .from("demo_itineraries")
  .select("*")
  .order("created_at", { ascending: false });

if (error) {
  console.error("Error fetching demo itineraries:", error);
  process.exit(1);
}

console.log(JSON.stringify(data, null, 2));
