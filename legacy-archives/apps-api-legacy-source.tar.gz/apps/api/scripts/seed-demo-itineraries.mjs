import { config } from "dotenv";
import { createClient } from "@supabase/supabase-js";

// Load environment variables from .env file
config({ path: "../../.env" });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY;
const placeholderUrls = ["https://example.supabase.co", "service-role-placeholder"];

if (!supabaseUrl || !supabaseKey) {
  console.warn("SUPABASE_URL or SUPABASE_SERVICE_KEY is missing. Skipping demo seed.");
  process.exit(0);
}

if (placeholderUrls.includes(supabaseUrl) || placeholderUrls.includes(supabaseKey)) {
  console.warn("Supabase env values are placeholder values. Skipping demo seed.");
  process.exit(0);
}

const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false },
});

const seedRows = [
  // Northern Vietnam
  {
    cities: ["Hanoi"],
    countries: ["VN"],
    start_date: "2026-06-12",
    end_date: "2026-06-14",
    num_days: 3,
    budget: 420.5,
    currency: "USD",
    trip_style: "culture",
    status: "complete",
    is_public: true,
    result: {
      title: "Weekend in Hanoi",
      overview: "A short cultural escape with street food and historic temples.",
      total_cost: 420.50,
      currency: "USD",
      num_days: 3,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-06-12",
          city: "Hanoi",
          title: "Old Quarter Exploration",
          activities: [
            {
              time: "08:00",
              name: "Hoan Kiem Lake",
              description: "Morning walk around the iconic lake",
              duration: "2 hours",
              cost: 0,
              currency: "USD",
              category: "attraction",
              maps_link: "https://maps.google.com/?q=Hoan+Kiem+Lake+Hanoi"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Hanoi", "Halong Bay"],
    countries: ["VN"],
    start_date: "2026-07-15",
    end_date: "2026-07-18",
    num_days: 4,
    budget: 850.0,
    currency: "USD",
    trip_style: "adventure",
    status: "complete",
    is_public: true,
    result: {
      title: "Hanoi & Halong Adventure",
      overview: "Explore Vietnam's capital and cruise through stunning Halong Bay.",
      total_cost: 850.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-07-15",
          city: "Hanoi",
          title: "Hanoi Arrival",
          activities: [
            {
              time: "14:00",
              name: "Temple of Literature",
              description: "Visit Vietnam's first university",
              duration: "2 hours",
              cost: 5,
              currency: "USD",
              category: "attraction",
              maps_link: "https://maps.google.com/?q=Temple+of+Literature+Hanoi"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Sapa"],
    countries: ["VN"],
    start_date: "2026-09-20",
    end_date: "2026-09-23",
    num_days: 4,
    budget: 650.0,
    currency: "USD",
    trip_style: "nature",
    status: "complete",
    is_public: true,
    result: {
      title: "Sapa Mountain Escape",
      overview: "Trek through terraced rice fields and ethnic villages.",
      total_cost: 650.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-09-20",
          city: "Sapa",
          title: "Mountain Arrival",
          activities: [
            {
              time: "15:00",
              name: "Sapa Market",
              description: "Explore local market and culture",
              duration: "3 hours",
              cost: 0,
              currency: "USD",
              category: "culture",
              maps_link: "https://maps.google.com/?q=Sapa+Market"
            }
          ]
        }
      ]
    }
  },

  // Central Vietnam
  {
    cities: ["Da Nang", "Hoi An"],
    countries: ["VN"],
    start_date: "2026-06-10",
    end_date: "2026-06-15",
    num_days: 6,
    budget: 850.0,
    currency: "USD",
    trip_style: "food",
    status: "complete",
    is_public: true,
    result: {
      title: "Da Nang & Hoi An Food Adventure",
      overview: "Culinary journey through Central Vietnam",
      total_cost: 850.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-06-10",
          city: "Da Nang",
          title: "Da Nang Arrival & Beach",
          activities: [
            {
              time: "14:00",
              name: "My Khe Beach",
              description: "Relax at the beautiful beach",
              duration: "3 hours",
              cost: 0,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=My+Khe+Beach+Da+Nang"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Da Nang"],
    countries: ["VN"],
    start_date: "2026-07-20",
    end_date: "2026-07-25",
    num_days: 6,
    budget: 1580.00,
    currency: "USD",
    trip_style: "relax",
    status: "complete",
    is_public: false,
    result: {
      title: "Da Nang Beach Break",
      overview: "Relaxing beach stay with family-friendly activities and local cuisine.",
      total_cost: 1580.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 4,
      days: [
        {
          day_number: 1,
          date: "2026-07-20",
          city: "Da Nang",
          title: "Beach Arrival",
          activities: [
            {
              time: "15:00",
              name: "My Khe Beach",
              description: "Check into hotel and relax at the beach",
              duration: "4 hours",
              cost: 0,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=My+Khe+Beach+Da+Nang"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Hue"],
    countries: ["VN"],
    start_date: "2026-08-05",
    end_date: "2026-08-08",
    num_days: 4,
    budget: 480.0,
    currency: "USD",
    trip_style: "culture",
    status: "complete",
    is_public: true,
    result: {
      title: "Imperial Hue Discovery",
      overview: "Explore Vietnam's ancient imperial city and royal tombs.",
      total_cost: 480.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-08-05",
          city: "Hue",
          title: "Imperial City",
          activities: [
            {
              time: "09:00",
              name: "Thien Mu Pagoda",
              description: "Visit the iconic seven-story pagoda",
              duration: "2 hours",
              cost: 3,
              currency: "USD",
              category: "attraction",
              maps_link: "https://maps.google.com/?q=Thien+Mu+Pagoda+Hue"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Nha Trang"],
    countries: ["VN"],
    start_date: "2026-10-01",
    end_date: "2026-10-05",
    num_days: 5,
    budget: 720.0,
    currency: "USD",
    trip_style: "beach",
    status: "complete",
    is_public: true,
    result: {
      title: "Nha Trang Beach Paradise",
      overview: "Crystal clear waters and vibrant marine life in Central Vietnam.",
      total_cost: 720.00,
      currency: "USD",
      num_days: 5,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-10-01",
          city: "Nha Trang",
          title: "Beach Welcome",
          activities: [
            {
              time: "16:00",
              name: "Nha Trang Beach",
              description: "Sunset beach walk and relaxation",
              duration: "3 hours",
              cost: 0,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=Nha Trang+Beach"
            }
          ]
        }
      ]
    }
  },

  // Southern Vietnam
  {
    cities: ["Ho Chi Minh City"],
    countries: ["VN"],
    start_date: "2026-11-10",
    end_date: "2026-11-13",
    num_days: 4,
    budget: 550.0,
    currency: "USD",
    trip_style: "urban",
    status: "complete",
    is_public: true,
    result: {
      title: "Ho Chi Minh City Explorer",
      overview: "Dive into Vietnam's bustling southern metropolis.",
      total_cost: 550.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-11-10",
          city: "Ho Chi Minh City",
          title: "City Arrival",
          activities: [
            {
              time: "14:00",
              name: "Ben Thanh Market",
              description: "Explore the famous central market",
              duration: "2 hours",
              cost: 0,
              currency: "USD",
              category: "shopping",
              maps_link: "https://maps.google.com/?q=Ben+Thanh+Market+Ho+Chi+Minh+City"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Ho Chi Minh City", "Cu Chi"],
    countries: ["VN"],
    start_date: "2026-12-01",
    end_date: "2026-12-04",
    num_days: 4,
    budget: 620.0,
    currency: "USD",
    trip_style: "history",
    status: "complete",
    is_public: true,
    result: {
      title: "Saigon & Cu Chi Tunnels",
      overview: "War history and vibrant city life in Southern Vietnam.",
      total_cost: 620.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-12-01",
          city: "Ho Chi Minh City",
          title: "War Remnants Museum",
          activities: [
            {
              time: "09:00",
              name: "War Remnants Museum",
              description: "Learn about Vietnam War history",
              duration: "3 hours",
              cost: 5,
              currency: "USD",
              category: "museum",
              maps_link: "https://maps.google.com/?q=War+Remnants+Museum+Ho+Chi+Minh+City"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Phu Quoc"],
    countries: ["VN"],
    start_date: "2026-01-15",
    end_date: "2026-01-20",
    num_days: 6,
    budget: 1200.0,
    currency: "USD",
    trip_style: "luxury",
    status: "complete",
    is_public: true,
    result: {
      title: "Phu Quoc Island Luxury",
      overview: "Premium beach resort experience on Vietnam's largest island.",
      total_cost: 1200.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-01-15",
          city: "Phu Quoc",
          title: "Island Arrival",
          activities: [
            {
              time: "16:00",
              name: "Sao Beach",
              description: "Private beach and sunset cocktails",
              duration: "4 hours",
              cost: 0,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=Sao+Beach+Phu+Quoc"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Da Lat"],
    countries: ["VN"],
    start_date: "2026-02-14",
    end_date: "2026-02-17",
    num_days: 4,
    budget: 480.0,
    currency: "USD",
    trip_style: "romantic",
    status: "complete",
    is_public: true,
    result: {
      title: "Da Lat Romantic Getaway",
      overview: "Flower city romance with French colonial charm.",
      total_cost: 480.00,
      currency: "USD",
      num_days: 4,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-02-14",
          city: "Da Lat",
          title: "Valentine's in Da Lat",
          activities: [
            {
              time: "18:00",
              name: "Xuân Huong Lake",
              description: "Romantic lakeside walk at sunset",
              duration: "2 hours",
              cost: 0,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=Xuan+Huong+Lake+Da+Lat"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Vung Tau"],
    countries: ["VN"],
    start_date: "2026-03-01",
    end_date: "2026-03-03",
    num_days: 3,
    budget: 350.0,
    currency: "USD",
    trip_style: "weekend",
    status: "complete",
    is_public: true,
    result: {
      title: "Vung Tau Weekend Escape",
      overview: "Quick coastal getaway from Ho Chi Minh City.",
      total_cost: 350.00,
      currency: "USD",
      num_days: 3,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-03-01",
          city: "Vung Tau",
          title: "Coastal Relaxation",
          activities: [
            {
              time: "10:00",
              name: "Front Beach",
              description: "Beach activities and seafood lunch",
              duration: "4 hours",
              cost: 15,
              currency: "USD",
              category: "leisure",
              maps_link: "https://maps.google.com/?q=Front+Beach+Vung+Tau"
            }
          ]
        }
      ]
    }
  },

  // Multi-city trips
  {
    cities: ["Hanoi", "Da Nang", "Ho Chi Minh City"],
    countries: ["VN"],
    start_date: "2026-04-01",
    end_date: "2026-04-10",
    num_days: 10,
    budget: 1800.0,
    currency: "USD",
    trip_style: "comprehensive",
    status: "complete",
    is_public: true,
    result: {
      title: "Vietnam North to South",
      overview: "Complete journey from Hanoi to Saigon exploring Vietnam's diversity.",
      total_cost: 1800.00,
      currency: "USD",
      num_days: 10,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-04-01",
          city: "Hanoi",
          title: "Northern Capital",
          activities: [
            {
              time: "08:00",
              name: "Ho Chi Minh Mausoleum",
              description: "Visit the preserved leader's resting place",
              duration: "1 hour",
              cost: 0,
              currency: "USD",
              category: "attraction",
              maps_link: "https://maps.google.com/?q=Ho+Chi+Minh+Mausoleum+Hanoi"
            }
          ]
        }
      ]
    }
  },
  {
    cities: ["Da Nang", "Hoi An", "Hue"],
    countries: ["VN"],
    start_date: "2026-05-10",
    end_date: "2026-05-15",
    num_days: 6,
    budget: 950.0,
    currency: "USD",
    trip_style: "heritage",
    status: "complete",
    is_public: true,
    result: {
      title: "Central Vietnam Heritage",
      overview: "UNESCO sites and imperial history in Central Vietnam.",
      total_cost: 950.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-05-10",
          city: "Da Nang",
          title: "Marble Mountains",
          activities: [
            {
              time: "09:00",
              name: "Son Tra Peninsula",
              description: "Hike and enjoy panoramic views",
              duration: "3 hours",
              cost: 5,
              currency: "USD",
              category: "nature",
              maps_link: "https://maps.google.com/?q=Son+Tra+Peninsula+Da+Nang"
            }
          ]
        }
      ]
    }
  },

  // Family trips
  {
    cities: ["Da Nang"],
    countries: ["VN"],
    start_date: "2026-06-20",
    end_date: "2026-06-25",
    num_days: 6,
    budget: 1400.0,
    currency: "USD",
    trip_style: "family",
    status: "complete",
    is_public: true,
    result: {
      title: "Da Nang Family Adventure",
      overview: "Perfect family destination with beaches and activities for all ages.",
      total_cost: 1400.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 4,
      days: [
        {
          day_number: 1,
          date: "2026-06-20",
          city: "Da Nang",
          title: "Family Beach Day",
          activities: [
            {
              time: "10:00",
              name: "Son Tra Peninsula",
              description: "Family-friendly hiking and picnic",
              duration: "4 hours",
              cost: 10,
              currency: "USD",
              category: "nature",
              maps_link: "https://maps.google.com/?q=Son+Tra+Peninsula+Da+Nang"
            }
          ]
        }
      ]
    }
  },

  // Budget trips
  {
    cities: ["Hanoi"],
    countries: ["VN"],
    start_date: "2026-07-01",
    end_date: "2026-07-03",
    num_days: 3,
    budget: 150.0,
    currency: "USD",
    trip_style: "budget",
    status: "complete",
    is_public: true,
    result: {
      title: "Budget Hanoi Explorer",
      overview: "Affordable cultural exploration on a tight budget.",
      total_cost: 150.00,
      currency: "USD",
      num_days: 3,
      num_travelers: 1,
      days: [
        {
          day_number: 1,
          date: "2026-07-01",
          city: "Hanoi",
          title: "Free Walking Tour",
          activities: [
            {
              time: "08:00",
              name: "Old Quarter Streets",
              description: "Self-guided walking tour of historic district",
              duration: "3 hours",
              cost: 0,
              currency: "USD",
              category: "culture",
              maps_link: "https://maps.google.com/?q=Old+Quarter+Hanoi"
            }
          ]
        }
      ]
    }
  },

  // Luxury trips
  {
    cities: ["Phu Quoc", "Con Dao"],
    countries: ["VN"],
    start_date: "2026-08-15",
    end_date: "2026-08-22",
    num_days: 8,
    budget: 3500.0,
    currency: "USD",
    trip_style: "luxury",
    status: "complete",
    is_public: false,
    result: {
      title: "Vietnam Islands Luxury",
      overview: "Exclusive island hopping with private villas and yacht charters.",
      total_cost: 3500.00,
      currency: "USD",
      num_days: 8,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-08-15",
          city: "Phu Quoc",
          title: "Private Villa Arrival",
          activities: [
            {
              time: "16:00",
              name: "Private Beach Villa",
              description: "Check into luxury beachfront villa",
              duration: "6 hours",
              cost: 0,
              currency: "USD",
              category: "accommodation",
              maps_link: "https://maps.google.com/?q=Luxury+Beach+Villa+Phu+Quoc"
            }
          ]
        }
      ]
    }
  },

  // Adventure trips
  {
    cities: ["Sapa", "Hanoi"],
    countries: ["VN"],
    start_date: "2026-09-10",
    end_date: "2026-09-15",
    num_days: 6,
    budget: 780.0,
    currency: "USD",
    trip_style: "adventure",
    status: "complete",
    is_public: true,
    result: {
      title: "Northern Vietnam Adventure",
      overview: "Trekking, homestays, and cultural immersion in the mountains.",
      total_cost: 780.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 3,
      days: [
        {
          day_number: 1,
          date: "2026-09-10",
          city: "Sapa",
          title: "Mountain Trek Start",
          activities: [
            {
              time: "08:00",
              name: "Muong Hoa Valley",
              description: "Guided trek through ethnic villages",
              duration: "6 hours",
              cost: 25,
              currency: "USD",
              category: "adventure",
              maps_link: "https://maps.google.com/?q=Muong+Hoa+Valley+Sapa"
            }
          ]
        }
      ]
    }
  },

  // Food-focused trips
  {
    cities: ["Ho Chi Minh City", "Hanoi"],
    countries: ["VN"],
    start_date: "2026-10-05",
    end_date: "2026-10-10",
    num_days: 6,
    budget: 680.0,
    currency: "USD",
    trip_style: "food",
    status: "complete",
    is_public: true,
    result: {
      title: "Vietnam Street Food Tour",
      overview: "Culinary journey from North to South Vietnamese cuisine.",
      total_cost: 680.00,
      currency: "USD",
      num_days: 6,
      num_travelers: 2,
      days: [
        {
          day_number: 1,
          date: "2026-10-05",
          city: "Hanoi",
          title: "Pho Capital",
          activities: [
            {
              time: "07:00",
              name: "Traditional Pho Breakfast",
              description: "Authentic Vietnamese noodle soup experience",
              duration: "1 hour",
              cost: 3,
              currency: "USD",
              category: "food",
              maps_link: "https://maps.google.com/?q=Pho+Restaurant+Hanoi"
            }
          ]
        }
      ]
    }
  }
];

const jobIds = seedRows.map((item) => item.result.title); // Use title as unique identifier

const deleteResponse = await supabase
  .from("itineraries")
  .delete()
  .in("result->>'title'", jobIds);

if (deleteResponse.error && deleteResponse.error.code !== "PGRST116") {
  console.warn("Warning: unable to clean prior demo rows.", deleteResponse.error.message);
}

const insertResponse = await supabase.from("itineraries").insert(seedRows);
if (insertResponse.error) {
  console.error("Failed to insert demo rows:", insertResponse.error);
  process.exit(1);
}

console.log(`Seeded ${seedRows.length} demo itinerary rows.`);