# Legacy Fastify API Reference

`apps/server` is now the NestJS API package.

This `apps/api` package is kept as the legacy/reference package so the previous Fastify route wiring and the business logic built so far can still be reviewed. During this transition, `apps/server` imports the compiled core from `apps/api/dist` while the domain/application code is being prepared for extraction into a dedicated core package.

Do not add new NestJS files here. New HTTP entrypoints should live under `apps/server/src/modules/*/interfaces/http`.
